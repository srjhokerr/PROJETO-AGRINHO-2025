function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// Variáveis do personagem

let fazendeiroX;

let fazendeiroY;

let tamanhoFazendeiro = 50;

let velocidadeFazendeiro = 5;

// Variáveis dos tomates

let tomates = [];

let quantidadeTomates = 10;

let tomatesColhidos = 0;

// Variáveis para os controles de toque

let btnCima, btnBaixo, btnEsquerda, btnDireita;

let tamanhoBotao = 60; // Tamanho dos botões de controle

// Imagens (se quiser usar, descomente e adicione os arquivos na mesma pasta do seu sketch.js)

// let imgFazendeiro;

// let imgTomate;

// let imgFundoFazenda;

function preload() {

  // Descomente e substitua 'caminho/para/sua/imagem.png' pelos caminhos reais das suas imagens

  // imgFazendeiro = loadImage('imagens/fazendeiro.png'); // Ex: um desenho de um fazendeiro

  // imgTomate = loadImage('imagens/tomate.png');     // Ex: um desenho de um tomate

  // imgFundoFazenda = loadImage('imagens/fazenda.png'); // Ex: uma imagem de fundo de fazenda

}

function setup() {

  // Cria o canvas para preencher a janela do navegador

  createCanvas(windowWidth, windowHeight);

  background(135, 206, 235); // Céu azul

  // Posição inicial do fazendeiro no centro inferior da tela

  fazendeiroX = width / 2;

  fazendeiroY = height - tamanhoFazendeiro / 2 - 100; // Um pouco mais acima para os botões

  // Gerar tomates em posições aleatórias

  for (let i = 0; i < quantidadeTomates; i++) {

    tomates.push({

      x: random(50, width - 50),

      y: random(50, height - 200), // Evita que apareçam muito perto dos botões

      colhido: false

    });

  }

  // Definir posições dos botões de controle

  btnEsquerda = { x: 50, y: height - 80, raio: tamanhoBotao / 2 };

  btnDireita = { x: 50 + tamanhoBotao * 1.5, y: height - 80, raio: tamanhoBotao / 2 };

  btnCima = { x: width - 80, y: height - 110, raio: tamanhoBotao / 2 };

  btnBaixo = { x: width - 80, y: height - 50, raio: tamanhoBotao / 2 };

  // Desabilita o menu de contexto ao segurar o toque

  // Isso evita que o navegador exiba o menu de "salvar imagem" quando você toca e segura

  // em um elemento canvas. É útil para jogos e apps interativos em dispositivos móveis.

  // window.addEventListener('contextmenu', e => e.preventDefault());

}

function draw() {

  background(144, 238, 144); // Verde claro para a fazenda

  // Desenhar a terra cultivada

  fill(139, 69, 19); // Cor de terra

  rect(0, height - 150, width, 150); // Faixa de terra na parte inferior, maior para os botões

  // Desenhar os tomates

  for (let i = 0; i < tomates.length; i++) {

    let t = tomates[i];

    if (!t.colhido) {

      // if (imgTomate) {

      //   image(imgTomate, t.x - 15, t.y - 15, 30, 30);

      // } else {

        fill(255, 0, 0); // Vermelho para o tomate

        ellipse(t.x, t.y, 20, 20); // Desenha um círculo para o tomate

        fill(0, 128, 0); // Verde para o cabinho

        rect(t.x - 2, t.y - 15, 4, 10);

      // }

    }

  }

  // Desenhar o fazendeiro

  // if (imgFazendeiro) {

  //   image(imgFazendeiro, fazendeiroX - tamanhoFazendeiro / 2, fazendeiroY - tamanhoFazendeiro / 2, tamanhoFazendeiro, tamanhoFazendeiro);

  // } else {

    fill(139, 69, 19); // Corpo marrom

    rect(fazendeiroX - 15, fazendeiroY - 20, 30, 40); // Tronco

    fill(255, 223, 186); // Cabeça cor de pele

    ellipse(fazendeiroX, fazendeiroY - 35, 30, 30); // Cabeça

    fill(0); // Olhos

    ellipse(fazendeiroX - 5, fazendeiroY - 38, 3, 3);

    ellipse(fazendeiroX + 5, fazendeiroY - 38, 3, 3);

    // Chapéu (opcional)

    fill(139, 69, 19);

    arc(fazendeiroX, fazendeiroY - 48, 40, 20, PI, TWO_PI); // Aba do chapéu

    rect(fazendeiroX - 10, fazendeiroY - 55, 20, 10); // Copa do chapéu

  // }

  // Desenhar os botões de controle

  desenharBotao(btnEsquerda.x, btnEsquerda.y, btnEsquerda.raio * 2, "<", "#f0f0f0", "#ccc");

  desenharBotao(btnDireita.x, btnDireita.y, btnDireita.raio * 2, ">", "#f0f0f0", "#ccc");

  desenharBotao(btnCima.x, btnCima.y, btnCima.raio * 2, "^", "#f0f0f0", "#ccc");

  desenharBotao(btnBaixo.x, btnBaixo.y, btnBaixo.raio * 2, "v", "#f0f0f0", "#ccc");

  // Mover o fazendeiro com base nos toques

  // loop através de todos os toques ativos

  for (let i = 0; i < touches.length; i++) {

    let touchX = touches[i].x;

    let touchY = touches[i].y;

    // Checar qual botão foi tocado

    if (dist(touchX, touchY, btnEsquerda.x, btnEsquerda.y) < btnEsquerda.raio) {

      fazendeiroX -= velocidadeFazendeiro;

    } else if (dist(touchX, touchY, btnDireita.x, btnDireita.y) < btnDireita.raio) {

      fazendeiroX += velocidadeFazendeiro;

    } else if (dist(touchX, touchY, btnCima.x, btnCima.y) < btnCima.raio) {

      fazendeiroY -= velocidadeFazendeiro;

    } else if (dist(touchX, touchY, btnBaixo.x, btnBaixo.y) < btnBaixo.raio) {

      fazendeiroY += velocidadeFazendeiro;

    }

  }

  // Limitar o fazendeiro dentro da tela (com margem para os botões na parte inferior)

  fazendeiroX = constrain(fazendeiroX, tamanhoFazendeiro / 2, width - tamanhoFazendeiro / 2);

  fazendeiroY = constrain(fazendeiroY, tamanhoFazendeiro / 2, height - tamanhoFazendeiro / 2 - 100); // 100 é a altura da área dos botões

  // Checar colisão com os tomates e "colher"

  for (let i = 0; i < tomates.length; i++) {

    let t = tomates[i];

    if (!t.colhido) {

      let d = dist(fazendeiroX, fazendeiroY, t.x, t.y);

      if (d < tamanhoFazendeiro / 2 + 10) { // Distância para colher

        t.colhido = true;

        tomatesColhidos++;

      }

    }

  }

  // Exibir a contagem de tomates

  fill(0);

  textSize(20);

  text('Tomates colhidos: ' + tomatesColhidos + ' / ' + quantidadeTomates, 20, 30);

  // Mensagem de "Todos os tomates colhidos!"

  if (tomatesColhidos === quantidadeTomates) {

    fill(0, 150, 0); // Verde para a mensagem

    textSize(40);

    textAlign(CENTER, CENTER);

    text('Parabéns! Todos os tomates colhidos!', width / 2, height / 2);

  }

}

// Função para desenhar um botão na tela

function desenharBotao(x, y, tamanho, texto, corFundo, corBorda) {

  fill(corFundo);

  stroke(corBorda);

  strokeWeight(2);

  ellipse(x, y, tamanho, tamanho);

  fill(0); // Cor do texto

  textSize(tamanho / 2);

  textAlign(CENTER, CENTER);

  text(texto, x, y + 2); // Ajuste fino para centralizar o texto

}

// Garante que o canvas se redimensione quando a janela (do navegador ou do celular) muda

function windowResized() {

  resizeCanvas(windowWidth, windowHeight);

  // Ajuste a posição do fazendeiro e dos botões se a tela for redimensionada

  fazendeiroX = width / 2;

  fazendeiroY = height - tamanhoFazendeiro / 2 - 100;

  btnEsquerda = { x: 50, y: height - 80, raio: tamanhoBotao / 2 };

  btnDireita = { x: 50 + tamanhoBotao * 1.5, y: height - 80, raio: tamanhoBotao / 2 };

  btnCima = { x: width - 80, y: height - 110, raio: tamanhoBotao / 2 };

  btnBaixo = { x: width - 80, y: height - 50, raio: tamanhoBotao / 2 };

}

// Necessário para o P5.js lidar corretamente com múltiplos toques e prevenir o zoom da página

function touchStarted() {

  return false; // Previne o comportamento padrão de rolagem/zoom do navegador

}

function touchMoved() {

  return false; // Previne o comportamento padrão de rolagem/zoom do navegador

}

function touchEnded() {

  return false; // Previne o comportamento padrão de rolagem/zoom do navegador

}